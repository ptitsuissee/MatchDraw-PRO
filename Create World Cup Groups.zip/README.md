
  # Create World Cup Groups

  This is a code bundle for Create World Cup Groups. The original project is available at https://www.figma.com/design/BfQZJyQQmMgz2o5WCvgNLz/Create-World-Cup-Groups.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  